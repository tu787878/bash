<?php

// Test
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/manage/change_option', array(
        'methods' => 'POST',
        'callback' => 'manage_change_option'
    ));
});
function manage_change_option()
{

    // authentication 
    $data = file_get_contents('php://input');

    parse_str($data, $data);
    $code = $data["code"];
    $code = base64_decode($code);
    $arr = explode(".",$code);
    
    $check = wp_authenticate_username_password( NULL, $arr[0], $arr[1] );

    if(!is_wp_error( $check )){
        $result = array('status' => 'success', 'code'=>0, 'data'=>$data["data"]);
        update_option($data["option"], $data["data"]);

        return $result;
    }
    $result = array('status' => 'fail', 'code'=>1);
    return $result;
} 

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/manage/save_popup', array(
        'methods' => 'POST',
        'callback' => 'manage_save_popup'
    ));
});
function manage_save_popup()
{

    // authentication 
    $data = file_get_contents('php://input');

    parse_str($data, $data);
    $code = $data["code"];
    $base64 = $data["base64"];

    $code = base64_decode($code);
    $arr = explode(".",$code);
    
    $check = wp_authenticate_username_password( NULL, $arr[0], $arr[1] );

    if(!is_wp_error( $check )){
        $image_id = save_image2($base64, '');
		$pos  = strpos($base64, ';');
		$type = explode(':', substr($base64, 0, $pos))[1];
        $output = "";
        if (intval($image_id) > 0) {
            update_option('ds_popup', $image_id);
            $url = wp_get_attachment_image_src( $image_id, 'medium', false );
            $output = is_ssl() ? preg_replace( "^http:", "https:", $url[0] ) : $url[0] ;
            $image = '<img id="myprefix-preview-image-popup" src="' . $output . '" />';
        } else {
			$image_id2 = get_option('ds_popup');
            $url = wp_get_attachment_image_src( $image_id2, 'medium', false );
            $output = is_ssl() ? preg_replace( "^http:", "https:", $url[0] ) : $url[0] ;
            $image = '<img id="myprefix-preview-image-popup" src="' . $output . '" />';
        }
        $result = array('status' => 'success', 'code'=>0, 'data' => $image, 'debug'=>explode("/", $type)[1]);
        return $result;
    }
    $result = array('status' => 'fail', 'code'=>1);
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/manage/get_version_plugin', array(
        'methods' => 'GET',
        'callback' => 'manage_get_version_plugin'
    ));
});
function manage_get_version_plugin()
{

    // authentication 
    $code = $_GET['code'];

    $code = base64_decode($code);
    $arr = explode(".",$code);
    
    $check = wp_authenticate_username_password( NULL, $arr[0], $arr[1] );

    if(!is_wp_error( $check )){
        $result = array('status' => 'success', 'code'=>0, 'data' => getVersion());
        return $result;
    }

    $result = array('status' => 'fail', 'code'=>1);
    return $result;
}

// Test
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/manage/get_popup', array(
        'methods' => 'GET',
        'callback' => 'manage_get_popup'
    ));
});
function manage_get_popup()
{

    // authentication 
    $code = $_GET['code'];
    $option = $_GET['option'];

    $code = base64_decode($code);
    $arr = explode(".",$code);
    
    $check = wp_authenticate_username_password( NULL, $arr[0], $arr[1] );

    if(!is_wp_error( $check )){
        $image_id = get_option($option);
        $output = "";
        if (intval($image_id) > 0) {
            $url = wp_get_attachment_image_src( $image_id, 'medium', false );
            $output = is_ssl() ? preg_replace( "^http:", "https:", $url[0] ) : $url[0] ;
            $image = '<img id="myprefix-preview-image-popup" src="' . $output . '" />';
        } else {
            $image = '<img id="myprefix-preview-image-popup" src="' . BOOKING_ORDER_PATH . '/img/no_img.jpg' . '" />';
        }
        $result = array('status' => 'success', 'code'=>0, 'data' => $image);
        return $result;
    }
    $result = array('status' => 'fail', 'code'=>1);
    return $result;
}

// Test
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/manage/get_option', array(
        'methods' => 'GET',
        'callback' => 'manage_get_option'
    ));
});
function manage_get_option()
{

    // authentication 
    $code = $_GET['code'];
    $option = $_GET['option'];

    $code = base64_decode($code);
    $arr = explode(".",$code);
    
    $check = wp_authenticate_username_password( NULL, $arr[0], $arr[1] );

    if(!is_wp_error( $check )){
        $data = get_option($option);
        $result = array('status' => 'success', 'code'=>0, 'data'=>$data);

        return $result;
    }
    $result = array('status' => 'fail', 'code'=>1);
    return $result;
}

//////////////////////////////////////////////////////////////////////

// Test
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/admin/load_appointment', array(
        'methods' => 'GET',
        'callback' => 'load_appointment'
    ));
});
function load_appointment()
{
    $data[] = [
        'id'              => $row->id,
        'title'           => $row->customer_name,
        'start'           => $row->start_time,
        'end'             => $row->end_time,
        'color'           => $row->color,
        'textColor'       => $row->text_color
    ];

    return $data;
}

//////////////////////////////////////////////////////////////////////

//auth
add_action('rest_api_init', function () {
    register_rest_route('ordertcg/v1', '/mobile/auth', array(
        'methods' => 'POST',
        'callback' => 'mobile_auth'
    ));
});

function mobile_auth()
{

    $data = file_get_contents('php://input');
    $data = explode("=", $data);
    //$data = json_decode($data);

    if (isset($data[1])) {
        $code = $data[1];
        $data_code = get_option("mobile_code");

        if (strcmp($code, $data_code) == 0) {
            $result = array('access_token' => '', 'status' => '', 'message' => '');
            $result['access_token'] = get_option("access_token_mobile");
            $result['status'] = 'success';
            $result['message'] = 'You got access token!';
            global $wpdb;
            $shop_name = $wpdb->get_row("SELECT shop_name FROM wp_shop_address WHERE id = 1 ")->shop_name;
            $result['shop_name'] = $shop_name;
            $result['logo'] = wp_get_attachment_image_src(get_option('ds_logo'), 'full')[0];
        } else {
            $result = array('access_token' => '', 'status' => '', 'message' => '', 'shop_name');
            $result['access_token'] = NULL;
            $result['status'] = 'failed';
            $result['message'] = 'Your code is incorrect!';
            $result['shop_name'] = NULL;
        }
    }
     return $result;
}

///////////////////////////////////////////////////
// shop_style
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/shop_style', array(
        'methods' => 'GET',
        'callback' => 'get_shop_style'
    ));
});

function get_shop_style()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $detail = array();
        $detail['theme'] = get_option('dsmart_theme_style');
        $detail['thumbnail'] = get_option('dsmart_thumbnail');
        $detail['float_cart'] = get_option('float_cart');

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
     return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/shop_style', array(
        'methods' => 'POST',
        'callback' => 'update_shop_style'
    ));
});

function update_shop_style()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];

        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_option('dsmart_thumbnail', $data['detail']['thumbnail'], 'yes');
            update_option('float_cart', $data['detail']['float_cart'], 'yes');
            update_option('dsmart_theme_style', $data['detail']['theme'], 'yes');

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

     return $result;
}

///////////////////////////////////////////////////
// general
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/general', array(
        'methods' => 'GET',
        'callback' => 'get_general'
    ));
});

function get_general()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $detail = array();
        $detail['currency'] = get_option('dsmart_currency');
        $detail['currency_rate'] = get_option('dsmart_currency_rate');
        $detail['show_second_number'] = get_option('show_second_number');
        $detail['google_key'] = get_option('dsmart_google_key');
        $detail['get_distance'] = get_option('get_distance');
        $detail['orderby'] = get_option('dsmart_orderby');
        $detail['order'] = get_option('dsmart_order');
        $detail['time_to_show_alert'] = get_option('time_to_show_alert');
        $detail['back_link_in_cart'] = get_option('back_link_in_cart');
        $detail['redirect_link_shop'] = get_option('redirect_link_shop');

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
     return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/general', array(
        'methods' => 'POST',
        'callback' => 'update_general'
    ));
});

function update_general()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];

        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_option('dsmart_currency', $data['detail']['currency'], 'yes');
            update_option('dsmart_currency_rate', $data['detail']['currency_rate'], 'yes');
            update_option('show_second_number', $data['detail']['show_second_number'], 'yes');
            update_option('dsmart_google_key', $data['detail']['google_key'], 'yes');
            update_option('get_distance', $data['detail']['get_distance'], 'yes');
            update_option('dsmart_orderby', $data['detail']['orderby'], 'yes');
            update_option('dsmart_order', $data['detail']['order'], 'yes');
            update_option('time_to_show_alert', $data['detail']['time_to_show_alert'], 'yes');
            update_option('back_link_in_cart', $data['detail']['back_link_in_cart'], 'yes');
            update_option('redirect_link_shop', $data['detail']['redirect_link_shop'], 'yes');

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

     return $result;
}

///////////////////////////////////////////////////
// payment
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/payment_method', array(
        'methods' => 'GET',
        'callback' => 'get_payment_method'
    ));
});

function get_payment_method()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $detail = array();
        $detail['dsmart_paypal'] = get_option('dsmart_paypal');
        $detail['dsmart_klarna'] = get_option('dsmart_klarna');
        $detail['dsmart_barzahlung'] = get_option('dsmart_barzahlung');
        $detail['dsmart_custom_method'] = get_option('dsmart_custom_method');
        $detail['dsmart_paypal_email_address'] = get_option('dsmart_paypal_email_address');
        $detail['dsmart_sandbox'] = get_option('dsmart_sandbox');
        $detail['klarna_username'] = get_option('klarna_username');
        $detail['klarna_password'] = get_option('klarna_password');

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
     return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/payment_method', array(
        'methods' => 'POST',
        'callback' => 'update_payment_method'
    ));
});

function update_payment_method()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];

        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_option('dsmart_paypal', $data['detail']['dsmart_paypal'], 'yes');
            update_option('dsmart_klarna', $data['detail']['dsmart_klarna'], 'yes');
            update_option('dsmart_barzahlung', $data['detail']['dsmart_barzahlung'], 'yes');
            update_option('dsmart_custom_method', $data['detail']['dsmart_custom_method'], 'yes');
            update_option('dsmart_paypal_email_address', $data['detail']['dsmart_paypal_email_address'], 'yes');
            update_option('dsmart_sandbox', $data['detail']['dsmart_sandbox'], 'yes');
            update_option('klarna_username', $data['detail']['klarna_username'], 'yes');
            update_option('klarna_password', $data['detail']['klarna_password'], 'yes');

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

     return $result;
}
//////////////////////////////////////////
// delivery
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/delivery', array(
        'methods' => 'GET',
        'callback' => 'get_delivery'
    ));
});

function get_delivery()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $detail = array();
        $detail['enable_pool'] = get_option('enable_pool');
        $detail['dsmart_method_ship'] = get_option('dsmart_method_ship');
        $detail['dsmart_method_direct'] = get_option('dsmart_method_direct');
        $detail['close_shop'] = get_option('dsmart_close_shop');
        $detail['delay_time'] = get_option('delay_time');
        $detail['delay_delivery'] = get_option('delay_delivery');
        $detail['time_open_shop_mo'] = get_option('time_open_shop_mo');
        $detail['time_close_shop_mo'] = get_option('time_close_shop_mo');
        $detail['time_open_shop_tu'] = get_option('time_open_shop_tu');
        $detail['time_close_shop_tu'] = get_option('time_close_shop_tu');
        $detail['time_open_shop_we'] = get_option('time_open_shop_we');
        $detail['time_close_shop_we'] = get_option('time_close_shop_we');
        $detail['time_open_shop_th'] = get_option('time_open_shop_th');
        $detail['time_close_shop_th'] = get_option('time_close_shop_th');
        $detail['time_open_shop_fr'] = get_option('time_open_shop_fr');
        $detail['time_close_shop_fr'] = get_option('time_close_shop_fr');
        $detail['time_open_shop_sa'] = get_option('time_open_shop_sa');
        $detail['time_close_shop_sa'] = get_option('time_close_shop_sa');
        $detail['time_open_shop_su'] = get_option('time_open_shop_su');
        $detail['time_close_shop_su'] = get_option('time_close_shop_su');
        $detail['time_open_shop_2_mo'] = get_option('time_open_shop_2_mo');
        $detail['time_close_shop_2_mo'] = get_option('time_close_shop_2_mo');
        $detail['time_open_shop_2_tu'] = get_option('time_open_shop_2_tu');
        $detail['time_close_shop_2_tu'] = get_option('time_close_shop_2_tu');
        $detail['time_open_shop_2_we'] = get_option('time_open_shop_2_we');
        $detail['time_close_shop_2_we'] = get_option('time_close_shop_2_we');
        $detail['time_open_shop_2_th'] = get_option('time_open_shop_2_th');
        $detail['time_close_shop_2_th'] = get_option('time_close_shop_2_th');
        $detail['time_open_shop_2_fr'] = get_option('time_open_shop_2_fr');
        $detail['time_close_shop_2_fr'] = get_option('time_close_shop_2_fr');
        $detail['time_open_shop_2_sa'] = get_option('time_open_shop_2_sa');
        $detail['time_close_shop_2_sa'] = get_option('time_close_shop_2_sa');
        $detail['time_open_shop_2_su'] = get_option('time_open_shop_2_su');
        $detail['time_close_shop_2_su'] = get_option('time_close_shop_2_su');

        $detail['closed_time'] = get_option('closed_time');
        if ($detail['closed_time'] == null) {

            $detail['closed_time'] = [];
        }

        $detail['closed_time_2'] = get_option('closed_time_2');
        if ($detail['closed_time_2'] == null) {

            $detail['closed_time_2'] = [];
        }
        $detail['dsmart_custom_date'] = get_option('dsmart_custom_date');
        $detail['dsmart_new_custom_date'] = get_option('dsmart_new_custom_date', '');
		
        $test = $detail['dsmart_custom_date'];
		$detail['dsmart_custom_date'] = [];
        foreach ($test as $key => $value) {
            $value['date'] = date(DATE_ISO8601, strtotime($value['date']));
			$detail['dsmart_custom_date'][] = $value;
        }

        $detail['dsmart_distance'] = get_option('dsmart_distance');
        $detail['dsmart_min_order'] = get_option('dsmart_min_order');
        $detail['dsmart_min_order_free_checkbox'] = get_option('dsmart_min_order_free_checkbox');
        $detail['dsmart_min_order_free'] = get_option('dsmart_min_order_free');
        $detail['dsmart_shipping_fee'] = get_option('dsmart_shipping_fee');
        $detail['dsmart_shipping_to'] = get_option('dsmart_shipping_to');
        $detail['dsmart_shipping_from'] = get_option('dsmart_shipping_from');
        $detail['dsmart_shipping_cs_fee'] = get_option('dsmart_shipping_cs_fee');
        $detail['dsmart_min_cs_fee'] = get_option('dsmart_min_cs_fee');

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
     return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/delivery', array(
        'methods' => 'POST',
        'callback' => 'update_delivery'
    ));
});

function update_delivery()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];

        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_option('dsmart_method_ship', $data['detail']['dsmart_method_ship'], 'yes');
            update_option('enable_pool', $data['detail']['enable_pool'], 'yes');
            update_option('dsmart_method_direct', $data['detail']['dsmart_method_direct'], 'yes');
            update_option('dsmart_close_shop', $data['detail']['close_shop'], 'yes');
            update_option('delay_time', $data['detail']['delay_time'], 'yes');
            update_option('delay_delivery', $data['detail']['delay_delivery'], 'yes');
            update_option('time_open_shop_mo', $data['detail']['time_open_shop_mo'], 'yes');
            update_option('time_close_shop_mo', $data['detail']['time_close_shop_mo'], 'yes');
            update_option('time_open_shop_tu', $data['detail']['time_open_shop_tu'], 'yes');
            update_option('time_close_shop_tu', $data['detail']['time_close_shop_tu'], 'yes');
            update_option('time_open_shop_we', $data['detail']['time_open_shop_we'], 'yes');
            update_option('time_close_shop_we', $data['detail']['time_close_shop_we'], 'yes');
            update_option('time_open_shop_th', $data['detail']['time_open_shop_th'], 'yes');
            update_option('time_close_shop_th', $data['detail']['time_close_shop_th'], 'yes');
            update_option('time_open_shop_fr', $data['detail']['time_open_shop_fr'], 'yes');
            update_option('time_close_shop_fr', $data['detail']['time_close_shop_fr'], 'yes');
            update_option('time_open_shop_sa', $data['detail']['time_open_shop_sa'], 'yes');
            update_option('time_close_shop_sa', $data['detail']['time_close_shop_sa'], 'yes');
            update_option('time_open_shop_su', $data['detail']['time_open_shop_su'], 'yes');
            update_option('time_close_shop_su', $data['detail']['time_close_shop_su'], 'yes');
            update_option('time_open_shop_2_mo', $data['detail']['time_open_shop_2_mo'], 'yes');
            update_option('time_close_shop_2_mo', $data['detail']['time_close_shop_2_mo'], 'yes');
            update_option('time_open_shop_2_tu', $data['detail']['time_open_shop_2_tu'], 'yes');
            update_option('time_close_shop_2_tu', $data['detail']['time_close_shop_2_tu'], 'yes');
            update_option('time_open_shop_2_we', $data['detail']['time_open_shop_2_we'], 'yes');
            update_option('time_close_shop_2_we', $data['detail']['time_close_shop_2_we'], 'yes');
            update_option('time_open_shop_2_th', $data['detail']['time_open_shop_2_th'], 'yes');
            update_option('time_close_shop_2_th', $data['detail']['time_close_shop_2_th'], 'yes');
            update_option('time_open_shop_2_fr', $data['detail']['time_open_shop_2_fr'], 'yes');
            update_option('time_close_shop_2_fr', $data['detail']['time_close_shop_2_fr'], 'yes');
            update_option('time_open_shop_2_sa', $data['detail']['time_open_shop_2_sa'], 'yes');
            update_option('time_close_shop_2_sa', $data['detail']['time_close_shop_2_sa'], 'yes');
            update_option('time_open_shop_2_su', $data['detail']['time_open_shop_2_su'], 'yes');
            update_option('time_close_shop_2_su', $data['detail']['time_close_shop_2_su'], 'yes');

            // merge_data
            $data1 = $data['detail']['closed_time'];
            $new1 = [];
            if (is_array($data1)) {
                for ($i = 0; $i < count($data1); $i = $i + 3) {

                    for ($j = 0; $j < 3; $j++) {
                        //$temp = explode(":", $datass[$i + $j]);
                        $n = $i + $j;
                        if (isset($data1[$i + $j]["date"])) {
                            $date = $data1[$i + $j]["date"];
                        } elseif (isset($data1[$i + $j]["from"])) {
                            $from = $data1[$i + $j]["from"];
                        } elseif (isset($data1[$i + $j]["to"])) {
                            $to = $data1[$i + $j]["to"];
                        }
                    }

                    $dd = array(
                        'date' => $date,
                        'from' => $from,
                        'to' => $to,
                    );
                    $new1[] = $dd;
                }
            }
            update_option('closed_time', $new1, 'yes'); //fix

            // merge_data
            $data2 = $data['detail']['closed_time_2'];
            $new2 = [];
            if (is_array($data2)) {
                for ($i = 0; $i < count($data2); $i = $i + 3) {

                    for ($j = 0; $j < 3; $j++) {
                        //$temp = explode(":", $datass[$i + $j]);
                        $n = $i + $j;
                        if (isset($data2[$i + $j]["date"])) {
                            $date = $data2[$i + $j]["date"];
                        } elseif (isset($data2[$i + $j]["from"])) {
                            $from = $data2[$i + $j]["from"];
                        } elseif (isset($data2[$i + $j]["to"])) {
                            $to = $data2[$i + $j]["to"];
                        }
                    }

                    $dd = array(
                        'date' => $date,
                        'from' => $from,
                        'to' => $to,
                    );
                    $new2[] = $dd;
                }
            }

            update_option('closed_time_2', $new2, 'yes'); //fix
            // merge_data
            $data3 = $data['detail']['dsmart_new_custom_date'];
            $new3 = [];

            if (is_array($data3)) {
                for ($i = 0; $i < count($data3); $i = $i + 7) {

                    for ($j = 0; $j < 7; $j++) {
                        //$temp = explode(":", $datass[$i + $j]);
                        $n = $i + $j;
                        if (isset($data3[$i + $j]["status"])) {
                            $status = $data3[$i + $j]["status"];
                        } elseif (isset($data3[$i + $j]["start_date"])) {
                            $start_date = $data3[$i + $j]["start_date"];
                        } elseif (isset($data3[$i + $j]["end_date"])) {
                            $end_date = $data3[$i + $j]["end_date"];
                        }
                        elseif (isset($data3[$i + $j]["date_type"])) {
                            $date_type = $data3[$i + $j]["date_type"];
                        }
                        elseif (isset($data3[$i + $j]["time_type"])) {
                            $time_type = $data3[$i + $j]["time_type"];
                        }
                        elseif (isset($data3[$i + $j]["start_time"])) {
                            $start_time = $data3[$i + $j]["start_time"];
                        }
                        elseif (isset($data3[$i + $j]["end_time"])) {
                            $end_time = $data3[$i + $j]["end_time"];
                        }
                    }

                    $dd = array(
                        'status' => $status,
                        'date_type' => $date_type,
                        'start_date' => $start_date,
                        'end_date' => $end_date,
                        'time_type' => $time_type,
                        'start_time' => $start_time,
                        'end_time' => $end_time,
                        
                    );
                    $new3[] = $dd;
                }
                //fix
            }
            if (count($new3) > 0) {
				update_option('dsmart_new_custom_date', $new3, 'yes');

				// convert to old dsmart_custom_date
				$array2 = array();
				foreach ($new3 as $item) {
					if($item["date_type"] === "single")
					{
						if($item["status"] === "close")
						{
							$array2[] = array("date" => $item["start_date"], "open" => "00:00", "close" => "00:00");
						}
						else
						{
							if($item["time_type"] === "time_to_time")
							{
								$array2[] = array("date" => $item["start_date"], "open" => $item["start_time"], "close" => $item["end_time"]);
							}
							else
							{
								$array2[] = array("date" => $item["start_date"], "open" => "00:00", "close" => "23:59");
							}
						}
					}
					else
					{
						$begin = new DateTime($item["start_date"]);
						$end = new DateTime($item["end_date"]);
						$end->modify('+1 day');
						$interval = DateInterval::createFromDateString('1 day');
						$period = new DatePeriod($begin, $interval, $end);

						foreach ($period as $dt) {
							$date = $dt->format("d-m-Y");
							if($item["status"] === "close")
							{
								$array2[] = array("date" => $date, "open" => "00:00", "close" => "00:00");
							}
							else
							{
								if($item["time_type"] === "time_to_time")
								{
									$array2[] = array("date" => $date, "open" => $item["start_time"], "close" => $item["end_time"]);
								}
								else
								{
									$array2[] = array("date" => $date, "open" => "00:00", "close" => "23:59");
								}
							}
						}
					}
				}
				update_option('dsmart_custom_date', $array2, 'yes');
			} else {
				update_option('dsmart_new_custom_date', "", 'yes');
				update_option('dsmart_custom_date', "", 'yes');
			}


            update_option('dsmart_distance', $data['detail']['dsmart_distance'], 'yes');
            update_option('dsmart_min_order', $data['detail']['dsmart_min_order'], 'yes');
            update_option('dsmart_min_order_free', $data['detail']['dsmart_min_order_free'], 'yes');
            update_option('dsmart_min_order_free_checkbox', $data['detail']['dsmart_min_order_free_checkbox'], 'yes');
            update_option('dsmart_shipping_fee', $data['detail']['dsmart_shipping_fee'], 'yes');
            update_option('dsmart_shipping_to', $data['detail']['dsmart_shipping_to'], 'yes');
            update_option('dsmart_shipping_from', $data['detail']['dsmart_shipping_from'], 'yes');
            update_option('dsmart_shipping_cs_fee', $data['detail']['dsmart_shipping_cs_fee'], 'yes');
            update_option('dsmart_min_cs_fee', $data['detail']['dsmart_min_cs_fee'], 'yes');

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

     return $result;
}

//******************************+ */
// Product category
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/product_categories', array(
        'methods' => 'GET',
        'callback' => 'get_product_categories'
    ));
});

function get_product_categories()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $args = array(
            'taxonomy' => 'product-cat',
            'hide_empty' => false,
            'search' => $_GET['date_from'],
        );

        $cats = get_categories($args);

        $dt = array(
            'detail' => $cats,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

//******************************+ */
// information
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/info', array(
        'methods' => 'GET',
        'callback' => 'get_info'
    ));
});

function get_info()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $detail = array();
        $detail['dsmart_taxonomy_text'] = get_option('dsmart_taxonomy_text');
        $detail['dsmart_thankyou_text'] = get_option('dsmart_thankyou_text');
        $detail['dsmart_term_text'] = get_option('dsmart_term_text');
        $detail['dsmart_cart_text'] = get_option('dsmart_cart_text');
        $detail['dsmart_cart_color'] = get_option('dsmart_cart_color');
        $detail['dsmart_cart_background'] = get_option('dsmart_cart_background');
        $detail['show_notify'] = get_option('show_notify');
        $detail['notify_text'] = get_option('notify_text');
        $detail['close_shop_text'] = get_option('close_shop_text');

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/info', array(
        'methods' => 'POST',
        'callback' => 'update_info'
    ));
});

function update_info()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];

        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_option('dsmart_taxonomy_text', $data['detail']['dsmart_taxonomy_text'], 'yes');
            update_option('dsmart_thankyou_text', $data['detail']['dsmart_thankyou_text'], 'yes');
            update_option('dsmart_term_text', $data['detail']['dsmart_term_text'], 'yes');
            update_option('dsmart_cart_text', $data['detail']['dsmart_cart_text'], 'yes');
            //update_option('dsmart_cart_color',$data['detail']['dsmart_cart_color'],'yes');
            //update_option('dsmart_cart_background',$data['detail']['dsmart_cart_background'],'yes');
            update_option('show_notify', $data['detail']['show_notify'], 'yes');
            update_option('close_shop_text', $data['detail']['close_shop_text'], 'yes');
            update_option('notify_text', $data['detail']['notify_text'], 'yes');

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}

//******************************+ */
// email-setting
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/email-setting', array(
        'methods' => 'GET',
        'callback' => 'get_email_setting'
    ));
});

function get_email_setting()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $detail = array();
        $detail['ds_mail_name'] = get_option('ds_mail_name');
        $detail['ds_sender_email'] = get_option('ds_sender_email');
        $detail['dsmart_header_mail_order'] = get_option('dsmart_header_mail_order');
        $detail['dsmart_text_mail_order'] = get_option('dsmart_text_mail_order');
        $detail['dsmart_header_mail_order_cs'] = get_option('dsmart_header_mail_order_cs');
        $detail['dsmart_text_mail_order_cs'] = get_option('dsmart_text_mail_order_cs');
        $detail['dsmart_header_mail_success_cs'] = get_option('dsmart_header_mail_success_cs');
        $detail['dsmart_text_mail_success_cs'] = get_option('dsmart_text_mail_success_cs');
        $detail['dsmart_header_mail_cancel_cs'] = get_option('dsmart_header_mail_cancel_cs');
        $detail['dsmart_text_mail_cancel_cs'] = get_option('dsmart_text_mail_cancel_cs');

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/email-setting', array(
        'methods' => 'POST',
        'callback' => 'update_email_setting'
    ));
});

function update_email_setting()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];

        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_option('ds_mail_name', $data['detail']['ds_mail_name'], 'yes');
            update_option('ds_sender_email', $data['detail']['ds_sender_email'], 'yes');
            update_option('dsmart_header_mail_order', $data['detail']['dsmart_header_mail_order'], 'yes');
            update_option('dsmart_text_mail_order', $data['detail']['dsmart_text_mail_order'], 'yes');
            update_option('dsmart_header_mail_order_cs', $data['detail']['dsmart_header_mail_order_cs'], 'yes');
            update_option('dsmart_text_mail_order_cs', $data['detail']['dsmart_text_mail_order_cs'], 'yes');
            update_option('dsmart_header_mail_success_cs', $data['detail']['dsmart_header_mail_success_cs'], 'yes');
            update_option('dsmart_text_mail_success_cs', $data['detail']['dsmart_text_mail_success_cs'], 'yes');
            update_option('dsmart_header_mail_cancel_cs', $data['detail']['dsmart_header_mail_cancel_cs'], 'yes');
            update_option('dsmart_text_mail_cancel_cs', $data['detail']['dsmart_text_mail_cancel_cs'], 'yes');

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}


//******************************+ */
// zipcode
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/zipcode', array(
        'methods' => 'GET',
        'callback' => 'get_zipcode'
    ));
});

function get_zipcode()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $detail = array();
        $detail['zipcode_status'] = get_option('zipcode_status');
        $detail['next_link_shortcode'] = get_option('next_link_shortcode');
        $detail['zipcode_data'] = get_option('zipcode_data');

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/zipcode', array(
        'methods' => 'POST',
        'callback' => 'update_zipcode'
    ));
});

function update_zipcode()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];

        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_option('zipcode_status', $data['detail']['zipcode_status'], 'yes');
            update_option('next_link_shortcode', $data['detail']['next_link_shortcode'], 'yes');

            // merge_data
            $data3 = $data['detail']['zipcode_data'];
            $new3 = [];

            for ($i = 0; $i < count($data3); $i = $i + 3) {

                for ($j = 0; $j < 3; $j++) {
                    //$temp = explode(":", $datass[$i + $j]);
                    $n = $i + $j;
                    if (isset($data3[$i + $j]["zipcode"])) {
                        $zipcode = $data3[$i + $j]["zipcode"];
                    } elseif (isset($data3[$i + $j]["minium_order"])) {
                        $minium_order = $data3[$i + $j]["minium_order"];
                    } elseif (isset($data3[$i + $j]["price"])) {
                        $price = $data3[$i + $j]["price"];
                    }
                }

                $dd = array(
                    'zipcode' => $zipcode,
                    'minium_order' => $minium_order,
                    'price' => $price,
                );
                $new3[] = $dd;
            }

            update_option('zipcode_data', $new3, 'yes');

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}


//+********************
// shop_standort
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/shop_standort', array(
        'methods' => 'GET',
        'callback' => 'get_shop_standort'
    ));
});

function get_shop_standort()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        global $wpdb;
        $table = "wp_shop_address";
        $detail = $wpdb->get_row("SELECT * FROM $table WHERE id = 1");

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/shop_standort', array(
        'methods' => 'POST',
        'callback' => 'update_shop_standort'
    ));
});

function update_shop_standort()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];
        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            global $wpdb;
            $table = "wp_shop_address";

            $wpdb->query("UPDATE $table SET shop_name = '" . $data["detail"]["shop_name"] . "', shop_address = '" . $data["detail"]["shop_address"] . "', email = '" . $data["detail"]["email"] . "' WHERE id = 1");

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}


//+********************
// dashboard
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/dashboard', array(
        'methods' => 'GET',
        'callback' => 'get_dashboard'
    ));
});

function get_dashboard()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $date_query = array();
        $meta_query = array();
        if (isset($_GET['date_from']) && $_GET['date_from'] != "") {
            $date_from = $_GET['date_from'];
            $date_from_data = explode('-', $date_from);
            $date_query['after'] = array(
                'year'  => $date_from_data[2],
                'month' => $date_from_data[1],
                'day'   => $date_from_data[0],
            );
        } else {
            $date_from = "";
        }
        if (isset($_GET['date_to']) && $_GET['date_to'] != "") {
            $date_to = $_GET['date_to'];
            $date_to_data = explode('-', $date_to);
            $date_query['before'] = array(
                'year'  => $date_to_data[2],
                'month' => $date_to_data[1],
                'day'   => $date_to_data[0],
            );
        } else {
            $date_to = "";
        }
        if (count($date_query) > 0) {
            $date_query['inclusive'] = true;
            $date_query['relation'] = 'AND';
        } else {
            $date_query = null;
        }
        if (isset($_GET['order-status']) && $_GET['order-status'] != "") {
            $status = $_GET['order-status'];
            $meta_query[] = array('key' => 'status', 'value' => $status, 'compare' => 'LIKE');
        } else {
            $status = "";
            $meta_query = null;
        }
        global $wp_query;

        $wp_query  = new WP_Query(array(
            'post_type'      => 'orders',
            'post_status'   => 'publish',
            'posts_per_page' => -1,
            'order'          => 'desc',
            'orderby' => 'date',
            'date_query' => $date_query,
            'meta_query' => $meta_query
        ));
        $total_all = 0;
        $post_count = $wp_query->post_count;
        if ($wp_query->have_posts()) :
            while ($wp_query->have_posts()) : $wp_query->the_post();
                $currency = dsmart_field('currency');
                $total = dsmart_field('total');
                $status = dsmart_field('status');
                $price_after_change = ds_convert_currency_price($currency, $total);
                $total_all = $total_all + $price_after_change;
            endwhile;
            wp_reset_query();
        endif;

        $detail["post_count"] = $post_count;
        $detail["total_all"] = ds_price_format_text_with_symbol($total_all, "2");

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/dashboard', array(
        'methods' => 'POST',
        'callback' => 'update_dashboard'
    ));
});

function update_dashboard()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];
        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            global $wpdb;
            $table = "wp_shop_address";

            $wpdb->query("UPDATE $table SET shop_name = '" . $data["detail"]["shop_name"] . "', shop_address = '" . $data["detail"]["shop_address"] . "', email = '" . $data["detail"]["email"] . "' WHERE id = 1");

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}


//+********************
// orders
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/orders', array(
        'methods' => 'GET',
        'callback' => 'get_orders'
    ));
});

function get_orders()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $date_query = array();
        $meta_query = array();
        if (isset($_GET['date_from']) && $_GET['date_from'] != "") {
            $date_from = $_GET['date_from'];
            $date_from_data = explode('-', $date_from);
            $date_query['after'] = array(
                'year'  => $date_from_data[2],
                'month' => $date_from_data[1],
                'day'   => $date_from_data[0],
            );
        } else {
            $date_from = "";
        }
        if (isset($_GET['date_to']) && $_GET['date_to'] != "") {
            $date_to = $_GET['date_to'];
            $date_to_data = explode('-', $date_to);
            $date_query['before'] = array(
                'year'  => $date_to_data[2],
                'month' => $date_to_data[1],
                'day'   => $date_to_data[0],
            );
        } else {
            $date_to = "";
        }
        if (count($date_query) > 0) {
            $date_query['inclusive'] = true;
            $date_query['relation'] = 'AND';
        } else {
            $date_query = null;
        }
        if (isset($_GET['status']) && $_GET['status'] != "") {
            $status = $_GET['status'];
            $meta_query[] = array(
                'key'  => 'status',
                'value'        => $status,
                'compare' => 'LIKE',
            );
        } else {
            $status = "";
        }
        if (count($meta_query) > 0) {
            $relations = array('relation' => 'AND');
        } else {
            $relations = array('relation' => 'OR');
            $meta_query = null;
        }
        global $wp_query;

        if (isset($_GET['paged']) && $_GET['paged'] != "") {
            $paged = $_GET['paged'];
        } else {
            $paged = 1;
        }
        $wp_query  = new WP_Query(array(
            'post_type'      => 'orders',
            'post_status'   => 'publish',
            'posts_per_page' => -1,
            'order'          => 'desc',
            'orderby' => 'date',
            'paged' => $paged,
            'date_query' => $date_query,
            'meta_query' => array(
                $meta_query,
                $relations
            ),
        ));

        //LOOP
        if ($wp_query->have_posts()) :
            while ($wp_query->have_posts()) : $wp_query->the_post();
                $currency = dsmart_field('currency');
                $customer_name1 = dsmart_field('customer_name1');
                $customer_name2 = dsmart_field('customer_name2');
                $customer_email = dsmart_field('customer_email');
                $customer_phone = dsmart_field('customer_phone');
                $total = dsmart_field('total');
                $status = dsmart_field('status');

                $d = [];

                $d["order"] = get_the_title();
                $d["name"] = $customer_name1 . ' ' . $customer_name2;
                $d["phone"] = $customer_phone;
                $d["email"] = $customer_email;
                $d["total"] = ds_price_format_text_with_symbol($total, $currency);
                $d["status"] = $status;
                $d["date"] = get_the_date();
                $d["id"] = get_the_ID();
                $detail[] = $d;

            endwhile;
            $pages = $wp_query->max_num_pages;
		 	
        endif;

        $dt = array(
            'detail' => $detail,
            'pages' => $pages,
        );
wp_reset_query();
        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/delete/order', array(
        'methods' => 'POST',
        'callback' => 'delete_order'
    ));
});

function delete_order()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];
        $data_token = get_option("access_token_mobile");
        $order_id = $data["order_id"];

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            wp_delete_post($order_id);

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}

//************************** */
// product-detail
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/detail_product', array(
        'methods' => 'GET',
        'callback' => 'get_detail_product'
    ));
});

function get_detail_product()
{
    $result = [];
    $token = $_GET['token'];
    $productId = $_GET['productId'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $product_image = get_post_meta($productId, '_thumbnail_id', true);
        $post = get_post($productId);
        $image_url = wp_get_attachment_image_src($product_image)[0];
        $test = get_option('closed_time');
        if ($test == null) {
            $test = [];
        };

        $enable_pool = get_option('enable_pool');
        if(strcmp($enable_pool, '1')  == 0){
            $pool = get_the_terms( $productId, 'pool' );
            $pools = get_terms( array(
                'taxonomy' => 'pool',
                'hide_empty' => false,
            ) );
        }else{
            $pool = [];
            $pools = [];
        }
        

        $dt = array(
            'image' => $image_url,
            'product' => $post,
            'test' => $test,
            'pool' => $pool[0],
            'enable_pool' => $enable_pool,
            'pools' => $pools,
        );
        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = $token;
    }
    return $result;
}


//************************** */
// product-category-detail
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/detail_product_category', array(
        'methods' => 'GET',
        'callback' => 'get_detail_product_category'
    ));
});

function get_detail_product_category()
{
    $result = [];
    $token = $_GET['token'];
    $t_id = $_GET['categoryId'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $term = get_term($t_id, 'product-cat');

        $tax_time = get_term_meta($t_id, 'tax_time', true);
        $category_pos = get_term_meta($t_id, 'category_pos', true);
        $pool = get_term_meta($t_id, 'pool', true);
        $term_image = get_term_meta($t_id, 'term_image', true);
        $can_not_use_coupon = get_term_meta($t_id, 'can_not_use_coupon', true);
        $time_array = [];

        $pools = get_terms( array(
            'taxonomy' => 'pool',
            'hide_empty' => false,
        ) );

        if ($tax_time != "" && is_array($tax_time) && count($tax_time) > 0) :
            foreach ($tax_time as $key => $item) :

                $temp = array(
                    'date' => $item['date'],
                    'open' => $item['open'],
                    'close' => $item['close'],

                );
                $time_array[] = $temp;

            endforeach;
        endif;

        $enable_pool = get_option('enable_pool');

        $image_url = wp_get_attachment_image_src($term_image)[0];

        $dt = array(
            'category_pos' => $category_pos,
            'pool' => $pool,
            'pools' => $pools,
            'enable_pool' => $enable_pool,
            'tax_time' => $time_array,
            'term_image' => $image_url,
            'name' => $term->name,
            'can_not_use_coupon' => $can_not_use_coupon,

        );
        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = $token;
    }
    return $result;
}

/**
 * Save the image on the server.
 */
function save_image($base64_img, $title)
{

    // Upload dir.
    $upload_dir  = wp_upload_dir();
    $upload_path = str_replace('/', DIRECTORY_SEPARATOR, $upload_dir['path']) . DIRECTORY_SEPARATOR;

    $img             = str_replace('data:image/jpeg;base64,', '', $base64_img);
    $img             = str_replace(' ', '+', $img);
    $decoded         = base64_decode($img);
    $filename        = $title . '.jpeg';
    $file_type       = 'image/jpeg';
    $hashed_filename = md5($filename . microtime()) . '_' . $filename;

    // Save the image in the uploads directory.
    $upload_file = file_put_contents($upload_path . $hashed_filename, $decoded);

    $attachment = array(
        'post_mime_type' => $file_type,
        'post_title'     => preg_replace('/\.[^.]+$/', '', basename($hashed_filename)),
        'post_content'   => '',
        'post_status'    => 'inherit',
        'guid'           => $upload_dir['url'] . '/' . basename($hashed_filename)
    );

    $attach_id = wp_insert_attachment($attachment, $upload_dir['path'] . '/' . $hashed_filename);
    return $attach_id;
}

function save_image2($base64_img, $title)
{

		$pos  = strpos($base64_img, ';');
		$type = explode(':', substr($base64_img, 0, $pos))[1];
	
    // Upload dir.
    $upload_dir  = wp_upload_dir();
    $upload_path = str_replace('/', DIRECTORY_SEPARATOR, $upload_dir['path']) . DIRECTORY_SEPARATOR;

    $img             = str_replace('data:'.$type.';base64,', '', $base64_img);
    $img             = str_replace(' ', '+', $img);
    $decoded         = base64_decode($img);
	
	
	
    $filename        = $title . '.' . explode("/", $type)[1];
    $file_type       = $type;
    $hashed_filename = md5($filename . microtime()) . '_' . $filename;

    // Save the image in the uploads directory.
    $upload_file = file_put_contents($upload_path . $hashed_filename, $decoded);

    $attachment = array(
        'post_mime_type' => $file_type,
        'post_title'     => preg_replace('/\.[^.]+$/', '', basename($hashed_filename)),
        'post_content'   => '',
        'post_status'    => 'inherit',
        'guid'           => $upload_dir['url'] . '/' . basename($hashed_filename)
    );

    $attach_id = wp_insert_attachment($attachment, $upload_dir['path'] . '/' . $hashed_filename);
    return $attach_id;
}


//************************** */
// update product category
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/product_category', array(
        'methods' => 'POST',
        'callback' => 'update_product_category'
    ));
});



function update_product_category()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];
        $data_token = get_option("access_token_mobile");
        $categoryId = $data["categoryId"];
        $categoryName = $data["categoryName"];
        $pool = $data["pool"];
        $categoryPosition = $data["categoryPosition"];
        $categoryImage = $data["categoryImage"];
        $dateArray = $data["dateArray"];
        $openArray = $data["openArray"];
        $closeArray = $data["closeArray"];
        $imageData = $data["imageData"];

        if ($imageData != null) {
            $imageId = save_image($imageData, '');
        }

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved! '. $pool .' zz';

            $array = array();
            if (is_array($dateArray) && count($dateArray) > 0) {
                foreach ($dateArray as $key => $value) {
                    $array[] = array('date' => $value, 'open' => $openArray[$key], 'close' => $closeArray[$key]);
                }
            } else {
                $array = "";
            }
            update_term_meta($categoryId, 'tax_time', $array);
            update_term_meta($categoryId, 'category_pos', $categoryPosition);

            $enable_pool = get_option('enable_pool');
            if(strcmp($enable_pool, '1')  == 0){
                update_term_meta($categoryId, 'pool', $pool);
            }
            

            if ($imageId != null) {
                update_term_meta($categoryId, 'term_image', $imageId);
            }

            wp_update_term($categoryId, 'product-cat', array(
                'name' => $categoryName,
            ));

            $result['data'] =  wp_get_attachment_image_src($imageId)[0];;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}

//************************** */
// update product detail
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/product_detail', array(
        'methods' => 'POST',
        'callback' => 'update_product_detail'
    ));
});



function update_product_detail()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];
        $data_token = get_option("access_token_mobile");
        $productId = $data["productId"];
        $productName = $data["productName"];
        $imageData = $data["imageData"];
        
        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            if ($imageData != null) {
                $imageId = save_image($imageData, '');
                update_post_meta($productId, '_thumbnail_id', $imageId);
            }
            
            $enable_pool = get_option('enable_pool');
            if(strcmp($enable_pool, '1')  == 0){
                $pool = $data["pool"];
                wp_set_post_terms($productId, $pool, 'pool');
            }

            $arg = array(
                'ID'            => $productId,
                'post_title'     => $productName,
            );
            wp_update_post($arg);

            $result['data'] = NULL;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}


//************************** */
// order-detail
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/order', array(
        'methods' => 'GET',
        'callback' => 'get_order'
    ));
});

function get_order()
{
    $result = [];
    $token = $_GET['token'];
    $orderId = $_GET['orderId'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $meta_values = get_post_meta($orderId);
        // $meta_values['ars'] = unserialize($meta_values['ar']);
        $item = unserialize($meta_values['item'][0]);
        $ar = unserialize($meta_values['ar'][0]);
        $post = get_post($orderId);
        $second_order_number = dsmart_field('second_order_number',$orderId);
        $newItem = [];
        foreach ($item as $value) {
            if (isset($value['variable_id'])) {
                $productId = $value['product_id'];
                $variable_id = intval(explode('_', $value['variable_id'])[1]) - 1;
                $variableName = get_post_meta($productId, "quantity", true)[$variable_id];
                $variablePrice = get_post_meta($productId, "varialbe_price", true)[$variable_id];

                $value['variable'] = true;
                $value['variableName'] = $variableName;
                $value['variablePrice'] = $variablePrice;
            } else {
                $value['variable'] = false;
            }

            if (isset($value['extra_info'])) {
                $productId = $value['product_id'];
                $extra_info = json_decode(stripslashes($value['extra_info']));

                foreach ($extra_info as $extra_key => $extra_value) {
                    $extra_id = intval(explode('_', $extra_value->extra_id)[1]) - 1;
                    $extra_quantity = $extra_value->extra_quantity;
                }

                $extraName = get_post_meta($productId, "extra_name", true)[$extra_id];
                $extraPrice = get_post_meta($productId, "extra_price", true)[$extra_id];
                $value['extra'] = true;
                $value['extraName'] = $extraName;
                $value['extraPrice'] = $extraPrice;
                $value['extraQuantity'] = $extra_quantity;
            } else {
                $value['extra'] = false;
            }

            $newItem[] = $value;
        }


        $ar = unserialize($meta_values['ar'][0]);
        $test = [];
        $test = unserialize($meta_values['ar'][0]);
        $dt = array(
            'detail' => $meta_values,
            'id' => $second_order_number,
            'item' => $newItem,
            'ar' => $ar,
            'post' => $post,
        );
        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = $token;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/done/order', array(
        'methods' => 'GET',
        'callback' => 'done_order'
    ));
});

function done_order()
{
    $result = [];
    $token = $_GET['token'];
    $orderId = $_GET['orderId'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        update_post_meta($orderId, "status", "completed");

        $result['data'] = NULL;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = $token;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/cancel/order', array(
        'methods' => 'GET',
        'callback' => 'cancel_order'
    ));
});

function cancel_order()
{
    $result = [];
    $token = $_GET['token'];
    $orderId = $_GET['orderId'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'Bestellung wurde abgelehnt';

        $field_status = dsmart_field('status', $orderId);
        if ($field_status == "processing" || $field_status == "pending") {
            update_post_meta($orderId, 'status', "cancelled");
            wp_send_mail_order($orderId, $field_status, "cancelled");
        } else {
            // $result['status'] = 'failed';
            // $result['message'] = 'Bestellung wurde vorher abgelehnt!';
            // $result['data'] = null;
            // return $result;
        }
        $result['data'] = NULL;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = $token;
    }
    
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mail/cancel/order', array(
        'methods' => 'GET',
        'callback' => 'cancel_order_mail'
    ));
});

function cancel_order_mail()
{
    $result = [];
    $token = $_GET['token'];
    $orderId = $_GET['orderId'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'Bestellung wurde abgelehnt';

        $field_status = dsmart_field('status', $orderId);
        if ($field_status == "processing" || $field_status == "pending") {
            update_post_meta($orderId, 'status', "cancelled");
            wp_send_mail_order($orderId, $field_status, "cancelled");
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Bestellung wurde vorher abgelehnt!';
            $result['data'] = null;
            return $result;
        }
        $result['data'] = NULL;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = $token;
        return $result;
    }
    wp_redirect( home_url() );
    exit();
    // return $result;
}




//+********************
// discount
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/discount', array(
        'methods' => 'GET',
        'callback' => 'get_discount'
    ));
});

function get_discount()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');

    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';

        $detail["discount_cod"] = get_option('discount_cod', "");
        $detail["discount_min"] = get_option('discount_min', "");
        $detail["discount_shop"] = get_option('discount_shop', "");
        $detail["type_promotion"] = get_option('type_promotion', "");
        $detail["promotion"] = get_option('promotion', "");
        $detail["type_promotion_2"] = get_option('type_promotion_2', "");
        $detail["promotion_2"] = get_option('promotion_2', "");
        $detail["time_discount_shop_mo"] = get_option('time_discount_shop_mo', "");
        $detail["time_discount_shop_tu"] = get_option('time_discount_shop_tu', "");
        $detail["time_discount_shop_we"] = get_option('time_discount_shop_we', "");
        $detail["time_discount_shop_th"] = get_option('time_discount_shop_th', "");
        $detail["time_discount_shop_fr"] = get_option('time_discount_shop_fr', "");
        $detail["time_discount_shop_sa"] = get_option('time_discount_shop_sa', "");
        $detail["time_discount_shop_su"] = get_option('time_discount_shop_su', "");
        $detail["time_discount_shop_2_mo"] = get_option('time_discount_shop_2_mo', "");
        $detail["time_discount_shop_2_tu"] = get_option('time_discount_shop_2_tu', "");
        $detail["time_discount_shop_2_we"] = get_option('time_discount_shop_2_we', "");
        $detail["time_discount_shop_2_th"] = get_option('time_discount_shop_2_th', "");
        $detail["time_discount_shop_2_fr"] = get_option('time_discount_shop_2_fr', "");
        $detail["time_discount_shop_2_sa"] = get_option('time_discount_shop_2_sa', "");
        $detail["time_discount_shop_2_su"] = get_option('time_discount_shop_2_su', "");
        $detail["dsmart_custom_discount_date"] = get_option('dsmart_custom_discount_date', "");

        $dt = array(
            'detail' => $detail,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/discount', array(
        'methods' => 'POST',
        'callback' => 'update_discount'
    ));
});

function update_discount()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];
        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_option('discount_cod', $data['detail']['discount_cod'], 'yes');
            update_option('discount_min', $data['detail']['discount_min'], 'yes');
            update_option('discount_shop', $data['detail']['discount_shop'], 'yes');
            update_option('type_promotion', $data['detail']['type_promotion'], 'yes');
            update_option('promotion', $data['detail']['promotion'], 'yes');
            update_option('type_promotion_2', $data['detail']['type_promotion_2'], 'yes');
            update_option('promotion_2', $data['detail']['promotion_2'], 'yes');
            update_option('time_discount_shop_mo', $data['detail']['time_discount_shop_mo'], 'yes');
            update_option('time_discount_shop_tu', $data['detail']['time_discount_shop_tu'], 'yes');
            update_option('time_discount_shop_we', $data['detail']['time_discount_shop_we'], 'yes');
            update_option('time_discount_shop_th', $data['detail']['time_discount_shop_th'], 'yes');
            update_option('time_discount_shop_fr', $data['detail']['time_discount_shop_fr'], 'yes');
            update_option('time_discount_shop_sa', $data['detail']['time_discount_shop_sa'], 'yes');
            update_option('time_discount_shop_su', $data['detail']['time_discount_shop_su'], 'yes');
            update_option('time_discount_shop_2_mo', $data['detail']['time_discount_shop_2_mo'], 'yes');
            update_option('time_discount_shop_2_tu', $data['detail']['time_discount_shop_2_tu'], 'yes');
            update_option('time_discount_shop_2_we', $data['detail']['time_discount_shop_2_we'], 'yes');
            update_option('time_discount_shop_2_th', $data['detail']['time_discount_shop_2_th'], 'yes');
            update_option('time_discount_shop_2_fr', $data['detail']['time_discount_shop_2_fr'], 'yes');
            update_option('time_discount_shop_2_sa', $data['detail']['time_discount_shop_2_sa'], 'yes');
            update_option('time_discount_shop_2_su', $data['detail']['time_discount_shop_2_su'], 'yes');


            // merge_data
            $data3 = $data['detail']['dsmart_custom_discount_date'];
            if($data3 != NULL){
                $new3 = [];

                for ($i = 0; $i < count($data3); $i = $i + 2) {
    
                    for ($j = 0; $j < 2; $j++) {
                        //$temp = explode(":", $datass[$i + $j]);
    
                        if (isset($data3[$i + $j]["date"])) {
                            $date = $data3[$i + $j]["date"];
                        } elseif (isset($data3[$i + $j]["time"])) {
                            $time = $data3[$i + $j]["time"];
                        }
                    }
    
                    $dd = array(
                        'date' => $date,
                        'time' => $time,
                    );
                    $new3[] = $dd;
                }
    
    
                update_option('dsmart_custom_discount_date', $new3, 'yes');
            }else{
                update_option('dsmart_custom_discount_date', "", 'yes');
            }
            

            $result['data'] = $data3;
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}



//+********************
// product
add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/get/product', array(
        'methods' => 'GET',
        'callback' => 'get_product'
    ));
});

function get_product()
{
    $result = [];
    $token = $_GET['token'];
    $result = array('status' => '', 'data' => [], 'message' => '');
    $search = $_GET['date_from'];
    $category = $_GET['category'];
    $data_token = get_option("access_token_mobile");

    if (strcmp($token, $data_token) == 0) {
        $result['status'] = 'success';
        $result['message'] = 'You got data!';


        $defaults = strcmp($category, '') != 0 ? array(
            'numberposts'      => 20,
            'orderby'          => 'date',
            'order'            => 'DESC',
            'include'          => array(),
            'exclude'          => array(),
            'meta_key'         => '',
            'meta_value'       => '',
            'post_type'        => 'product',
            'suppress_filters' => true,
            's' => $search,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product-cat',
                    'field'    => 'slug',
                    'terms'    => $category
                )
            )
        ) : array(
            'numberposts'      => 20,
            'orderby'          => 'date',
            'order'            => 'DESC',
            'include'          => array(),
            'exclude'          => array(),
            'meta_key'         => '',
            'meta_value'       => '',
            'post_type'        => 'product',
            'suppress_filters' => true,
            's' => $search,

        );

        $parsed_args = wp_parse_args($args, $defaults);
        if (empty($parsed_args['post_status'])) {
            $parsed_args['post_status'] = ('attachment' === $parsed_args['post_type']) ? 'inherit' : 'publish';
        }
        if (!empty($parsed_args['numberposts']) && empty($parsed_args['posts_per_page'])) {
            $parsed_args['posts_per_page'] = $parsed_args['numberposts'];
        }
        // if (!empty($parsed_args['category'])) {
        //     $parsed_args['cat'] = $parsed_args['category'];
        // }
        if (!empty($parsed_args['include'])) {
            $incposts                      = wp_parse_id_list($parsed_args['include']);
            $parsed_args['posts_per_page'] = count($incposts);  // Only the number of posts included.
            $parsed_args['post__in']       = $incposts;
        } elseif (!empty($parsed_args['exclude'])) {
            $parsed_args['post__not_in'] = wp_parse_id_list($parsed_args['exclude']);
        }

        $parsed_args['ignore_sticky_posts'] = true;
        $parsed_args['no_found_rows']       = true;

        $get_posts = new WP_Query;
        $products = $get_posts->query($parsed_args);

        $args = array(
            'taxonomy' => 'product-cat',
            'orderby' => 'name',
            'order'   => 'ASC',
            'hide_empty' => false
        );

        $cats = get_categories($args);

        foreach ($products as $product) {
            $product->stock = get_post_meta($product->ID, $key = 'status');
        }

        $dt = array(
            'detail' => $products,
            'test' => $category,
            'categories' => $cats,
        );

        $result['data'] = $dt;
    } else {
        $result['status'] = 'failed';
        $result['message'] = 'Your token is incorrect!';
        $result['data'] = NULL;
    }
    return $result;
}

add_action('rest_api_init', function () {

    register_rest_route('ordertcg/v1', '/mobile/update/product', array(
        'methods' => 'POST',
        'callback' => 'update_product'
    ));
});

function update_product()
{
    $result = array('status' => '', 'data' => [], 'message' => '');
    $data = file_get_contents('php://input');

    parse_str($data, $data);

    if (isset($data["access_token"])) {
        $token = $data["access_token"];
        $data_token = get_option("access_token_mobile");

        if (strcmp($token, $data_token) == 0) {
            $result['status'] = 'success';
            $result['message'] = 'Your setting have been saved!';

            update_post_meta($data["id"], 'status', $data["value"]);

            $result['data'] = $data["id"];
        } else {
            $result['status'] = 'failed';
            $result['message'] = 'Your token is incorrect!';
            $result['data'] = NULL;
        }
    }

    return $result;
}
